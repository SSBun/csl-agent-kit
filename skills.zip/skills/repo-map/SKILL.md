---
name: repo-map
description: Build a lightweight map and project glossary before exploring an unknown repository or unfamiliar module. Use before broad code exploration, feature work in a new codebase, architecture orientation, or when the agent and user need shared vocabulary for key domain concepts, classes, types, entry points, responsibilities, and call relationships. Use CodeGraph when available.
---

# Repo Map

Build a compact, objective structure map and shared glossary before editing or deep-diving. This skill is for orientation, not a full audit report, project inventory, or recommendation document. Describe what the component does, how files/modules are organized, and which key types own which responsibilities.

## Output

Produce a short map in the conversation unless the user asks for a file. Include objective information confirmed from file structure, docs, CodeGraph, call-site tracing, tests, or code reading. Do not add subjective opinions, risk assessments, confidence ratings, recommendations, open questions, or audit findings.

If the working folder contains multiple child git repositories, produce one `Project Glossary` and `Working Map` per repository. Do not merge unrelated projects into one glossary.

If the user asks to save the map, write `docs/analysis/repo-map.md` in the target repo. Choose the closest format guide under `references/`; do not copy example facts into the target report.

### Component Summary

Start with 1-3 concise sentences describing what this component, repo, or scoped area does for users or the business. This is not a stack summary. Mention the main product responsibility and the code boundary that implements it, based on code/docs evidence.

### Project Glossary

Define the vocabulary the user and agent need to discuss the business logic without ambiguity:

- **Domain terms** — product/business words used in UI text, docs, tests, models, APIs, or filenames.
- **Code terms** — key classes, types, protocols/interfaces, modules, commands, events, stores, jobs, or services.
- **Meaning in this project** — what the term means here, not the generic dictionary definition.
- **Not the same as** — nearby terms that are easy to confuse.
- **Source** — the file, type, test, route, or doc that supports the definition.

Keep the glossary small but useful. Prefer 8-20 terms for a new repo, or 5-12 terms for a focused module. If a term is inferred rather than explicit, mark it as an inference.

### Working Map

1. **File structure** — top-level or scoped folders that implement product behavior, with their concrete paths.
2. **Modules** — modules or subsystems, where they live, and their main duties.
3. **Key types** — important classes/types/protocols and their main duties.
4. **Core data/control flows** — short objective flows observed in code, with participating types.

Keep it practical: 5-12 key types are usually enough. If the repo is large, map only the area relevant to the user's task.

## Workflow

1. **Resolve project roots**
   - Run `git rev-parse --show-toplevel` from the working folder.
   - If it succeeds, treat that git root as the project root unless the user scoped a child module.
   - If it fails, check immediate child folders for git repositories with a command like:
     - `find . -maxdepth 2 -type d -name .git -prune`
   - If child git repositories exist, map each repository separately or ask the user which repo to focus on when there are too many.
   - If neither the root nor child folders are git repositories, treat the working folder as one loose project and say that no git root was found.

2. **Define scope**
   - If the user named a feature, bug, file, symbol, or module, map that area first.
   - If the task is generic, map the app/library entry points and the top-level domain modules.
   - Do not read every file by default.

3. **Inventory each repo**
   - Use `rg --files`, manifests, README, build files, and test directories.
   - Identify the stack from files such as `package.json`, `Package.swift`, `pyproject.toml`, `Cargo.toml`, `go.mod`, `build.gradle`, `.xcodeproj`, or `.sln`.
   - Identify the project kind before choosing the output format: `web`, `backend`, `apple`, or `android`.
   - Collect repeated domain words from directory names, type names, API routes, UI labels, tests, fixtures, docs, and config.
   - Do not put obvious inventory in the final map unless it identifies where a module lives or what the component owns.

4. **Use CodeGraph when available**
   - Check with `command -v codegraph`.
   - Run CodeGraph per project root, not once for a parent folder that only contains several unrelated repos.
   - If `.codegraph/` exists inside a project root, run `codegraph sync <project-root>` or `codegraph status <project-root>`.
   - If CodeGraph is installed but not initialized and indexing is reasonable for that repo size, run `codegraph init <project-root>`.
   - Use `codegraph files`, `codegraph query <symbol-or-domain-word>`, `codegraph callers <symbol>`, `codegraph callees <symbol>`, and `codegraph impact <symbol>` to inspect relationships.
   - If CodeGraph is unavailable, too slow, or fails, fall back to `rg`, language-aware file names, and direct reads.

5. **Find key types**
   - Prefer types that sit on boundaries: app roots, controllers, services, stores, reducers, models, protocols/interfaces, dependency containers, API clients, persistence layers, and coordinators.
   - Use names, imports, inheritance/conformance, call sites, and tests to judge importance.
   - For each key type, identify:
     - Main duty in the component.
     - Main collaborators.
     - Owned state or data.
     - External effects: filesystem, network, database, UI, process, shell, or analytics.
     - Tests or fixtures that describe expected behavior.

6. **Build the glossary**
   - Define domain terms from how the project uses them.
   - Tie each glossary entry to code evidence: file path, type, route, test, fixture, or README section.
   - Include confusing pairs when present, such as account/user, project/workspace, task/job, session/run, model/entity, client/server, local/remote, draft/published.
   - Keep unclear terms explicit: mark `Unknown` when evidence is insufficient instead of guessing.

7. **Trace relationships**
   - Start from entry points and follow calls to domain logic.
   - For a named task, trace from the user-facing action or failing symbol toward the business logic and persistence/API boundary.
   - Use CodeGraph callers/callees/impact for symbols when possible; otherwise use `rg` for type names and method names.

8. **Stop at a usable map**
   - Stop when you can define the component summary, relevant vocabulary, file structure, modules, key type duties, and main objective flows.
   - Do not turn this into `analyze-project`; use that skill only when the user wants a formal multi-report analysis.

## CodeGraph Notes

- Do not run `codegraph uninit` unless the user explicitly asks.
- If indexing would touch a very large repo or generated/vendor directories, prefer status/query if already indexed; otherwise ask before a long index.
- Treat CodeGraph output as a navigation aid, not proof. Confirm important conclusions by reading the relevant files.

## Reference

- `references/repo-map-web-example.md` — web frontend format guide. Prefer this for React, Vue, Svelte, Next.js frontend, SPA, or browser UI repos.
- `references/repo-map-backend-example.md` — backend service format guide. Prefer this for API servers, workers, service modules, persistence-heavy repos, or backend-only packages.
- `references/repo-map-apple-example.md` — iOS/macOS/Apple development format guide. Prefer this when the repo has `.xcodeproj`, `.xcworkspace`, `Package.swift` with app targets, SwiftUI, UIKit, AppKit, or XCTest.
- `references/repo-map-android-example.md` — Android format guide. Prefer this when the repo has Gradle Android plugins, `AndroidManifest.xml`, Kotlin/Java Android code, Jetpack Compose, XML layouts, or Android tests.

## Rules

- Use this before broad exploration of an unknown repo or unfamiliar module.
- Detect git roots before mapping; analyze child git repositories separately when the working folder is just a container.
- Match the report format to one of the four project kinds: web, backend, apple, or android.
- Keep the map small enough to guide action.
- Include a concise component summary before the glossary.
- Treat glossary accuracy as part of repo understanding; do not hide uncertain definitions.
- Exclude subjective opinions, risk assessments, confidence ratings, recommendations, open questions, and audit findings.
- Include file/module paths when they clarify where responsibilities live.
- Favor concrete file/type names over architecture labels.
- Do not modify source files during mapping unless the user explicitly asks for implementation.
- If the map reveals a matching SOP or skill, mention it before continuing.
